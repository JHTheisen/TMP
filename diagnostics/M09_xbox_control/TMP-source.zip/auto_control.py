﻿"""Single-request manual/keyframe workflow; no pygame, serial or hardware access."""
from dataclasses import dataclass
import math
from celestial_control import CelestialTracker, parse_tracking_command, RESULT_MAX_AGE
from celestial_targets import NamedTarget
from stepped_playback import PhotoSettings, SteppedPlayback


@dataclass(frozen=True)
class Keyframe:
    epoch: int
    steps: tuple
    heading: str
    pitch: str


class AutoSession:
    """Keyframe actions are available from manual; only active actions gate JOG."""
    def __init__(self):
        self.enabled = True
        self.phase = "READY"
        self.note = "Manual positioning; LB/RB capture, Home plays A to B."
        self.increment = 1
        self.duration = 10
        self.frames = {}
        self.epoch = None
        self.request_id = 0
        self.pending_id = self.purpose = self.deadline = self.last_rx = None
        self.continuation = None
        self.last_command = ""
        self.action = None
        self.play_duration = 10
        self.settle_until = None
        self.motion_started = None
        self.raw_command = None
        self.celestial = None
        self.celestial_ready = False
        self.celestial_status = ""
        self.celestial_feedback = ""
        self.celestial_source = ""
        self._manual_rearm_required = False
        self.photo_settings = PhotoSettings()
        self.stepped = None
        self.camera_events = []
        self.orientation_fields = {}
        self.orientation_received_at = None

    def pointing_ready(self, now):
        fields = self.orientation_fields
        if self.orientation_received_at is None or any(fields.get(key) != value for key, value in (
                ("protocol", "2"), ("feedback", "AS5600"), ("available", "YES"),
                ("fresh", "YES"), ("north_set", "YES"), ("level_set", "YES"))):
            return False
        try:
            age = float(fields["age_ms"]) / 1000 + max(0, now - self.orientation_received_at)
            angles = (float(fields["heading"]), float(fields["physical_pitch"]))
        except (KeyError, TypeError, ValueError):
            return False
        return math.isfinite(age) and 0 <= age <= 2.0 and all(math.isfinite(v) for v in angles)

    def _require_manual_rearm(self):
        self._manual_rearm_required = True

    def consume_manual_rearm_required(self):
        required = self._manual_rearm_required
        self._manual_rearm_required = False
        return required

    def configure_celestial(self, observer, reference):
        if self.celestial is not None:
            self.celestial.close()
        self.celestial = CelestialTracker(observer, reference) if observer is not None else None

    def request_celestial(self, command, now, centered, dry_run=False):
        target = command if isinstance(command, NamedTarget) else parse_tracking_command(command)
        if self.celestial is None:
            raise ValueError("Celestial tracking needs valid --latitude and --longitude settings.")
        if not dry_run and (not self.enabled or self.phase != "READY"):
            raise ValueError("Wait for READY before celestial GOTO; request was not queued.")
        if not centered:
            raise ValueError("Center sticks for 0.5 s before celestial GOTO.")
        if not dry_run and not self.pointing_ready(now):
            raise ValueError("Celestial GOTO requires protocol 2, fresh AS5600 feedback, SET NORTH and SET LEVEL.")
        self.celestial_status = (target.name if isinstance(target, NamedTarget) else
                                 f"RA={target.ra_hours:.6f} h Dec={target.dec_deg:+.6f} deg")
        self.celestial_source = target.name if isinstance(target, NamedTarget) else "RA/DEC"
        if dry_run:
            self.note = "Celestial dry run: " + self.celestial_status + "; no motion or coordinate calculation."
            return None
        self.celestial.begin(target, now)
        self._new_request("celestial", "CELESTIAL_PREPARING", now)
        self.action = "celestial"
        self.raw_command = None
        self.continuation = None
        self.celestial_ready = False
        self.celestial_feedback = ""
        self.last_rx = now
        self.deadline = now + 15.0
        self.note = "Preparing current sky position; waiting for stopped READY."
        return self._command("STOP")

    def request_track_here(self, now, centered, sensor_fields, sensor_received_at, dry_run=False):
        """Capture the current encoder boresight and enter the existing sky tracker."""
        if self.celestial is None:
            raise ValueError("TRACK HERE needs valid --latitude and --longitude settings; manual remains available.")
        if not dry_run and (not self.enabled or self.phase != "READY"):
            raise ValueError("Wait for READY before TRACK HERE; request was not queued.")
        if not centered:
            raise ValueError("Center sticks for 0.5 s before TRACK HERE.")
        fields = sensor_fields or {}
        if sensor_received_at is None:
            raise ValueError("TRACK HERE needs a recent encoder orientation report; manual remains available.")
        required = (("available", "YES"), ("has_sample", "YES"), ("fresh", "YES"),
                    ("protocol", "2"), ("feedback", "AS5600"), ("north_set", "YES"), ("level_set", "YES"), ("pitch_axis", "PITCH"))
        failed = [name for name, expected in required if fields.get(name) != expected]
        if failed:
            raise ValueError("TRACK HERE needs fresh, calibrated encoder heading and physical pitch "
                             f"({', '.join(failed)} unavailable); manual remains available.")
        try:
            sample_age = float(fields["age_ms"]) / 1000.0
            receipt_age = max(0.0, now - float(sensor_received_at))
            heading = float(fields["heading"])
            pitch = float(fields["physical_pitch"])
        except (KeyError, TypeError, ValueError, OverflowError) as error:
            raise ValueError("TRACK HERE received invalid encoder orientation telemetry; manual remains available.") from error
        if (not all(math.isfinite(value) for value in (sample_age, receipt_age, heading, pitch)) or
                sample_age < 0 or sample_age + receipt_age > 2.0):
            raise ValueError("TRACK HERE encoder orientation is stale or invalid; manual remains available.")
        try:
            horizontal = self.celestial.reference.horizontal_from_mount(heading, pitch)
            self.celestial.reference.mount_target(horizontal)  # Existing horizon and pitch guards.
        except ValueError as error:
            raise ValueError(f"TRACK HERE cannot use the current pointing: {error}; manual remains available.") from error
        self.celestial_status = (f"TRACK HERE captured Alt={horizontal.altitude_deg:.3f} "
                                 f"Az={horizontal.azimuth_deg:.3f} deg | resolving RA/Dec")
        self.celestial_source = "TRACK HERE"
        if dry_run:
            self.note = "Celestial dry run: " + self.celestial_status + "; no motion or coordinate calculation."
            return None
        try:
            self.celestial.begin_here(horizontal, now)
        except Exception as error:
            self.celestial.cancel()
            raise ValueError(f"TRACK HERE could not start: {error}; manual remains available.") from error
        self._new_request("celestial", "CELESTIAL_PREPARING", now)
        self.action = "celestial"
        self.raw_command = None
        self.continuation = None
        self.celestial_ready = False
        self.celestial_feedback = ""
        self.last_rx = now
        self.deadline = now + 15.0
        self.note = "Captured current pointing; resolving its sky target and waiting for stopped READY."
        return self._command("STOP")

    def celestial_display_lines(self):
        if not self.celestial_status:
            return []
        rows = [f"CELESTIAL | {self.phase} | {self.celestial_status}"]
        if self.celestial:
            rows += [self.celestial.observer.describe(), self.celestial.reference.describe()]
        if self.celestial_feedback:
            rows.append(self.celestial_feedback)
        return rows + [self.note]

    def close(self):
        if self.celestial is not None:
            self.celestial.close()

    @property
    def busy(self):
        return self.phase not in ("READY", "OFF", "FAULT")

    @property
    def overridable(self):
        return self.busy and self.action not in (None, "capture_a", "capture_b")

    def invalidate(self, reason):
        self.frames.clear()
        self.epoch = None
        self.note = "Captures cleared: " + reason

    def cancel(self, now, reason="STOP sent; wait for READY."):
        self.stepped = None
        self.camera_events.clear()
        if self.celestial is not None:
            self.celestial.cancel()
        self.phase = "STOPPING"
        self.pending_id = self.purpose = self.continuation = self.action = None
        self.settle_until = None
        self.deadline = now + 4.0
        self.note = reason

    def enter(self, now):
        self.enabled = True
        self.last_rx = now
        self.cancel(now)

    def leave(self, now):
        self.cancel(now)

    def _new_request(self, purpose, phase, now):
        self.request_id = self.request_id % 4294967295 + 1
        self.pending_id = self.request_id
        self.purpose = purpose
        self.phase = phase
        self.deadline = now + 4.0
        return self.pending_id

    def _command(self, line):
        self.last_command = line
        return (line + "\n").encode("ascii")

    def _snapshot(self, now):
        ident = self._new_request(self.action, "SNAPSHOT", now)
        self.continuation = self._command(f"SNAP {ident}")

    def raw_sent(self, command, now):
        """Observe an explicitly sent autonomous command for the same takeover.

        This does not parse/admit its arguments or generate a second request.
        Idle raw editing still suppresses JOG; only an in-flight motion can be
        reclaimed by deliberate sticks.
        """
        words = command.split()
        if words and words[0] == "STOP" and self.action == "celestial":
            self.cancel(now)
            return
        if words and words[0] in ("LEVEL", "NORTH", "POSE", "MOVE", "KEYMOVE", "KEYRETURN"):
            self.action = "raw"
            self.raw_command = words[0]
            self.phase = "MOVE_PENDING"
            self.pending_id = self.continuation = None
            self.deadline = now + 4.0
            self.last_rx = now

    def _alignment(self):
        return self.action.upper() if self.action in ("level", "north") else (
            self.raw_command if self.action == "raw" and self.raw_command in ("LEVEL", "NORTH") else None)

    def request(self, action, now, centered):
        if not self.enabled or self.phase != "READY":
            self.note = "Not queued: wait for current action to finish and release controls."
            return None
        if action not in ("capture_a", "capture_b") and not centered:
            self.note = "Not queued: center sticks before requesting movement."
            return None
        if action in ("return_a", "play", "play_stepped") and "A" not in self.frames:
            self.note = "Capture A first."
            return None
        if action in ("play", "play_stepped") and "B" not in self.frames:
            self.note = "Capture B first."
            return None
        self.action = action
        self.raw_command = None
        self.play_duration = self.duration
        self.stepped = (SteppedPlayback(self.frames["A"], self.frames["B"], self.photo_settings, self.duration)
                        if action == "play_stepped" else None)
        self.phase = "PREFLIGHT_STOP"
        self.pending_id = self.continuation = None
        self.last_rx = now
        self.deadline = now + 4.0
        self.note = "Stopping manual motion before a fresh position request."
        return self._command("STOP")

    def _finish(self, note):
        self.stepped = None
        if self.action == "celestial" and self.celestial is not None:
            self.celestial.cancel()
        self.phase = "FINISH_WAIT"
        self.pending_id = self.purpose = self.continuation = self.action = None
        self.note = note + " Waiting for READY."

    def receive(self, line, now):
        self.last_rx = now
        fields = dict(token.split("=", 1) for token in line.split() if "=" in token)
        if line.startswith("ORIENTATION_STATE "):
            self.orientation_fields = fields
            self.orientation_received_at = now
        if line.startswith(("M09_xbox_control:", "KEYFRAME_INVALIDATED ")) or line == "M09 ABORTED":
            if line.startswith("M09_xbox_control:"):
                self.orientation_fields = {}
                self.orientation_received_at = None
            self.invalidate(line)
            if line.startswith("KEYFRAME_INVALIDATED ") and self._alignment():
                # A forced watchdog stop loses captures but firmware may recover
                # this encoder-dependent command. Do not invent a persistent host latch.
                return
            self.cancel(now, self.note)
            if line == "M09 ABORTED":
                self.phase = "FAULT"
                self.deadline = None
                self.note += "; firmware abort is latched; reset required."
            return
        if line == "M09 READY":
            if self.phase == "CELESTIAL_PREPARING":
                self.celestial_ready = True
            elif self.action == "celestial" and self.phase in ("CELESTIAL_GOTO", "CELESTIAL_TRACK"):
                # READY after a firmware reset/stop must never leave a host
                # update source alive, even if a terminal telemetry line was lost.
                self._require_manual_rearm()
                self._finish("Celestial operation ended at firmware READY.")
                self.phase = "READY"
                self.deadline = None
            elif self.phase == "PREFLIGHT_STOP":
                if self.action in ("capture_a", "capture_b", "return_a", "play", "play_stepped"):
                    self._snapshot(now)
                elif self.action in ("set_north", "set_level", "level", "north"):
                    self._new_request(self.action, "MOVE_PENDING", now)
                    self.continuation = self._command(self.action.upper())
                else:
                    moves = {"pitch_up": (0, self.increment), "pitch_down": (0, -self.increment),
                             "yaw_right": (self.increment, 0), "yaw_left": (-self.increment, 0)}
                    yaw, pitch = moves[self.action]
                    self._new_request(self.action, "MOVE_PENDING", now)
                    self.continuation = self._command(f"MOVE {yaw} {pitch} 0")
            elif self.phase == "RETURN_WAIT":
                self.phase = "AT_A_SETTLE"
                self.settle_until = now + .2
                self.deadline = now + 4.0
                self.note = "Generated-step return complete; checking stopped A before timed playback."
            elif self.phase == "PHOTO_READY_WAIT" and self.stepped is not None:
                # RESULT PASS proves all motors stopped at the requested steps;
                # READY confirms the firmware released the completed operation.
                self.phase = "PHOTO_SETTLE"
                self.settle_until = now + self.stepped.settings.settle_seconds
                self.deadline = self.settle_until + 4.0
                self.note = "Photo waypoint stopped; settling before camera event."
            elif self.phase in ("STOPPING", "FINISH_WAIT"):
                self.phase = "READY"
                self.deadline = None
            elif self.action == "raw" and self.phase == "MOVE_ACTIVE":
                self.phase = "READY"
                self.pending_id = self.purpose = self.deadline = self.action = None
            return
        if self.action == "celestial" and fields.get("id") == str(self.pending_id):
            if line.startswith("CELESTIAL_ACCEPTED ") and self.phase == "CELESTIAL_GOTO_PENDING":
                self.phase = "CELESTIAL_GOTO"
                self.motion_started = now
                self.deadline = now + 95.0
            if line.startswith(("CELESTIAL_ACCEPTED ", "CELESTIAL_DEADLINE ")):
                if self.phase == "CELESTIAL_GOTO":
                    try:
                        duration = int(fields["deadline_ms"])
                        if 0 < duration < 2147483648:
                            self.deadline = self.motion_started + duration / 1000.0 + 5.0
                    except (ValueError, KeyError):
                        pass
                return
            if line.startswith("CELESTIAL_TRACK ") or (
                    line.startswith("CELESTIAL_STATE ") and fields.get("mode") == "TRACK"):
                if self.phase in ("CELESTIAL_GOTO", "CELESTIAL_TRACK"):
                    self.phase = "CELESTIAL_TRACK"
                    self.deadline = None
                    self.note = "Tracking; move sticks to take over, Space/F12 STOP, B abort."
            if line.startswith("CELESTIAL_STATE "):
                self.celestial_feedback = fields.get("feedback", "UNKNOWN") + " target/error yaw=" + fields.get("yaw_target", "?") + "/" + fields.get("yaw_error", "?") + " pitch=" + fields.get("pitch_target", "?") + "/" + fields.get("pitch_error", "?") + " deg"
                return
            if line.startswith("CELESTIAL_RESULT "):
                if fields.get("status") == "FAILED":
                    self._require_manual_rearm()
                self._finish(line)
                self.deadline = now + 4.0
                return
            if line.startswith("CELESTIAL_REJECTED "):
                # Rejected live updates may leave braking outstanding. STOP is
                # also safe for rejected admission and guarantees a new READY.
                self._require_manual_rearm()
                self.cancel(now, line)
                self.continuation = self._command("STOP")
                return
        if self.action in ("set_north", "set_level") and line.startswith("CALIBRATION "):
            self._finish(line)
            self.deadline = now + 4.0
            if "REJECTED" in line:
                self.continuation = self._command("STATUS")
            return
        alignment = self._alignment()
        if alignment and line.startswith(alignment + " ACCEPTED") and self.phase == "MOVE_PENDING":
            self.phase = "MOVE_ACTIVE"
            self.motion_started = now
            self.deadline = None  # Firmware owns displacement/progress timing.
        if alignment and line.startswith((alignment + " ACCEPTED", alignment + " DEADLINE", alignment + " RESUMED")):
            if self.phase == "MOVE_ACTIVE":
                try:
                    duration = int(fields["deadline_ms"])
                    if 0 < duration < 2147483648:
                        self.deadline = self.motion_started + duration / 1000.0 + 5.0
                except (ValueError, KeyError):
                    pass
            return
        if alignment and line.startswith((alignment + " REJECTED:", alignment + " RESULT:")):
            self._finish(line)
            self.deadline = now + 4.0
            return
        if self.action == "raw" and line.startswith(("KEYMOVE ACCEPTED", "KEYMOVE RESULT", "KEYMOVE REJECTED", "KEYRETURN REJECTED")):
            if line.startswith("KEYMOVE ACCEPTED"):
                self.phase = "MOVE_ACTIVE"
                self.deadline = None  # Firmware deadline, plus the common receive lease below.
            else:
                self._finish(line)
                self.deadline = now + 4.0
            return
        matching = self.pending_id is not None and fields.get("id") == str(self.pending_id)
        if line.startswith("KEYFRAME_SNAPSHOT ") and matching and self.phase == "SNAPSHOT":
            try:
                epoch = int(fields["epoch"])
                steps = tuple(int(fields[name]) for name in ("yaw_steps", "pitch_steps", "carriage_steps"))
                if not 1 <= epoch <= 4294967295 or any(not -2147483648 <= value <= 2147483647 for value in steps):
                    raise ValueError("out of range")
            except (ValueError, KeyError):
                self.note = "Malformed snapshot ignored; waiting for correlated valid response."
                return
            if self.epoch is not None and epoch != self.epoch:
                self.invalidate("firmware position epoch changed")
                self._finish(self.note)
                return
            self.epoch = epoch
            snapshot = Keyframe(epoch, steps, fields.get("heading", "?"), fields.get("physical_pitch", "?"))
            if self.action in ("capture_a", "capture_b"):
                slot = "A" if self.action == "capture_a" else "B"
                self.frames[slot] = snapshot
                self.phase = "READY"
                self.pending_id = self.purpose = self.deadline = self.action = None
                self.note = f"Captured {slot}: steps {steps}; startup-relative and unhomed."
                return
            at_a = steps == self.frames["A"].steps
            if self.purpose == "verify_a" and not at_a:
                self._finish("Stopped A verification failed; playback canceled.")
                return
            travel = self.action == "return_a" or not at_a
            target = self.frames["A" if travel else "B"]
            if target.epoch != epoch:
                self.invalidate("keyframe epoch mismatch")
                self._finish(self.note)
                return
            if self.stepped is not None and not travel:
                self._prepare_photo_move(now)
                return
            ident = self._new_request("return" if travel else "play", "KEYMOVE_PREPARED", now)
            line = f"{'KEYRETURN' if travel else 'KEYMOVE'} {ident} {epoch} {target.steps[0]} {target.steps[1]} {target.steps[2]}"
            self.continuation = self._command(line if travel else line + f" {self.play_duration * 1000}")
            self.note = "Returning to A at travel speed." if travel else "Timed A to B; generated-step endpoints only."
        elif matching and line.startswith(("SNAP REJECTED ", "KEYMOVE REJECTED ", "KEYRETURN REJECTED ")):
            self._finish(line)
            self.deadline = now + 4.0
        elif matching and self.phase == "KEYMOVE_PENDING" and line.startswith("KEYMOVE ACCEPTED "):
            self.phase = "KEYMOVE_ACTIVE"
            self.deadline = now + (65 if self.purpose == "return" else
                                   (self.stepped.segment_ms / 1000 + 5 if self.stepped else self.play_duration + 5))
        elif matching and self.phase in ("KEYMOVE_PENDING", "KEYMOVE_ACTIVE") and line.startswith("KEYMOVE RESULT "):
            if fields.get("status") == "FAILED":
                self.invalidate("keyframe motion failed")
            if fields.get("status") == "PASS" and self.purpose == "return" and self.action in ("play", "play_stepped"):
                self.phase = "RETURN_WAIT"
                self.pending_id = self.continuation = None
            elif fields.get("status") == "PASS" and self.purpose == "photo" and self.stepped is not None:
                try:
                    actual = tuple(int(fields[name]) for name in ("yaw_steps", "pitch_steps", "carriage_steps"))
                    valid = int(fields["epoch"]) == self.stepped.start.epoch and actual == self.stepped.last_target
                except (KeyError, ValueError):
                    valid = False
                if not valid:
                    self._finish("Photo waypoint confirmation invalid; no camera event.")
                else:
                    self.phase = "PHOTO_READY_WAIT"
                    self.pending_id = self.continuation = None
            else:
                self._finish(line)
            self.deadline = now + 4.0
        elif self.phase == "MOVE_PENDING" and line.startswith(("POSE ACCEPTED", "PITCH-ONLY ACCEPTED")):
            self.phase = "MOVE_ACTIVE"
            self.deadline = now + 95.0
        elif self.phase == "MOVE_PENDING" and line.startswith(("POSE REJECTED:", "POSE ALREADY AT TARGET:")):
            self._finish(line)
            self.deadline = now + 4.0
        elif self.phase == "MOVE_ACTIVE" and ("FINAL RESULT:" in line or line.startswith("OPERATION FAILED:")):
            self._finish(line)
            self.deadline = now + 4.0

    def frame(self, now):
        if self.busy and ((self.deadline is not None and now >= self.deadline) or
                          (self.last_rx is not None and now - self.last_rx > 3.0)):
            if self.action == "celestial":
                self._require_manual_rearm()
            self.invalidate("autonomous acknowledgment/telemetry timed out; coordinate confidence unknown")
            self.cancel(now, self.note)
            self.phase = "FAULT"
            self.deadline = None
            return b"STOP\n"
        if self.stepped is not None and self.phase in ("PHOTO_SETTLE", "PHOTO_POST"):
            if now < self.settle_until:
                return None
            if self.phase == "PHOTO_SETTLE":
                self.camera_events.append(self.stepped.trigger(now))
                self.phase = "PHOTO_POST"
                self.settle_until = now + self.stepped.settings.post_seconds
                self.deadline = self.settle_until + 4.0
                self.note = f"Camera event {self.stepped.index}/{self.stepped.settings.segments}; motors stopped."
                return None
            if self.stepped.complete:
                self.stepped = None
                self.phase = "READY"
                self.pending_id = self.purpose = self.continuation = self.action = self.deadline = None
                self.note = "Stepped playback complete at B; photo events delivered."
                return None
            self._prepare_photo_move(now)
        if self.action == "celestial":
            try:
                if self.phase == "CELESTIAL_PREPARING":
                    result = self.celestial.result(now)
                    if result is None:
                        result = self.celestial.latest
                    if result is not None and self.celestial_ready:
                        if now - result.requested_at > RESULT_MAX_AGE:
                            if not self.celestial.pending:
                                self.celestial._request(now)
                            return None
                        self.phase = "CELESTIAL_GOTO_PENDING"
                        self.deadline = now + 4.0
                        self.celestial.sent(now)
                        self._describe_celestial(result)
                        return self._command(f"CELESTIAL_GOTO {self.pending_id} {result.mount.heading_deg:.6f} {result.mount.pitch_deg:.6f}")
                elif self.phase in ("CELESTIAL_GOTO", "CELESTIAL_TRACK"):
                    result = self.celestial.update(now)
                    if result is not None:
                        self.celestial.sequence += 1
                        self.celestial.sent(now)
                        self._describe_celestial(result)
                        return self._command(f"CELESTIAL_UPDATE {self.pending_id} {self.celestial.sequence} {result.mount.heading_deg:.6f} {result.mount.pitch_deg:.6f}")
            except Exception as error:
                self._require_manual_rearm()
                self.cancel(now, f"Celestial canceled: {error}")
                return self._command("STOP")
        if self.phase == "AT_A_SETTLE" and now >= self.settle_until:
            self._snapshot(now)
            self.purpose = "verify_a"
        if self.continuation is not None:
            command, self.continuation = self.continuation, None
            if self.phase == "KEYMOVE_PREPARED":
                self.phase = "KEYMOVE_PENDING"
                self.deadline = now + 4.0
            return command
        return None

    def _prepare_photo_move(self, now):
        self.stepped.last_target = self.stepped.target()
        ident = self._new_request("photo", "KEYMOVE_PREPARED", now)
        yaw, pitch, carriage = self.stepped.last_target
        self.continuation = self._command(
            f"KEYMOVE {ident} {self.stepped.start.epoch} {yaw} {pitch} {carriage} {self.stepped.segment_ms}")
        self.note = f"Moving to photo waypoint {self.stepped.index + 1}/{self.stepped.settings.segments}."

    def take_camera_events(self):
        """Nonblocking hook: consume exposure requests only after a confirmed stop.

        The default host logs these events. A future shutter adapter can consume
        them without changing waypoint or ESP32 motion execution.
        """
        events, self.camera_events = self.camera_events, []
        return events

    def _describe_celestial(self, result):
        target = self.celestial.target
        prefix = "TRACK HERE | " if self.celestial_source == "TRACK HERE" else ""
        coordinates = (target.name if isinstance(target, NamedTarget) else
                       f"{prefix}RA={target.ra_hours:.6f} h Dec={target.dec_deg:+.6f} deg")
        self.celestial_status = (f"{coordinates} | "
                                 f"Alt={result.horizontal.altitude_deg:.3f} Az={result.horizontal.azimuth_deg:.3f} deg | "
                                 f"UTC={result.utc.isoformat(timespec='seconds')}")
        if result.horizontal.warnings:
            self.celestial_status += " | " + "; ".join(result.horizontal.warnings)

    def display_lines(self):
        captures = " | ".join(f"{slot}={self.frames[slot].steps if slot in self.frames else 'not saved'}" for slot in ("A", "B"))
        return [f"MANUAL + KEYFRAMES | {self.phase} | increment {self.increment} deg | duration {self.duration} s",
                "LB (4): capture A | RB (5): capture B | X button (2): duration | Home (10): Play A->B",
                "LS click (8): return A | RS click (9): 1/2 deg | D-pad: up/down pitch, right/left yaw",
                "A (0): LEVEL pitch | Y (3): NORTH yaw (magnetic)",
                "Space/F12: STOP | B / keyboard X: abort; hold B 2s to exit | Move sticks to take over automatic motion",
                f"Generated steps (startup-relative, unhomed): {captures}", self.note] + self.celestial_display_lines()
